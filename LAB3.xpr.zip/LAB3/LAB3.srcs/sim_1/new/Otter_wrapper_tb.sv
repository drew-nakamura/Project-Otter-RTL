`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: 
// 
// Create Date: 04/30/2026 02:06:28 PM
// Design Name: 
// Module Name: Otter_wrapper_tb
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////


module OTTER_Wrapper_tb;

    // DUT signals
    logic CLK;
    logic BTNC;
    logic [15:0] SWITCHES;
    logic [15:0] LEDS;
    logic [7:0] CATHODES;
    logic [3:0] ANODES;

    // Instantiate DUT
    OTTER_Wrapper dut (
        .CLK(CLK),
        .BTNC(BTNC),
        .SWITCHES(SWITCHES),
        .LEDS(LEDS),
        .CATHODES(CATHODES),
        .ANODES(ANODES)
    );

    // 🔹 Clock generation (10ns period = 100MHz)
    initial begin
        CLK = 0;
        forever #5 CLK = ~CLK;
    end

    // 🔹 Stimulus
    initial begin
        // Initialize inputs
        BTNC = 1;           // assert reset
        SWITCHES = 16'd0;

        #20;                // hold reset for a few cycles
        BTNC = 0;           // release reset

        // Let CPU run
        #1000;

        // Change switches (optional test)
        SWITCHES = 16'hAAAA;
        #200;

        SWITCHES = 16'h5555;
        #200;

        // Finish simulation
        $stop;
    end

endmodule
