`timescale 1ns / 1ps
//////////////////////////////////////////////////////////////////////////////////
// Company: 
// Engineer: Drew Nakamura
// 
// Create Date: 04/27/2026 12:05:23 PM
// Design Name: 
// Module Name: Drews_pipeline_toplevel
// Project Name: 
// Target Devices: 
// Tool Versions: 
// Description: 
// 
// Dependencies: 
// 
// Revision:
// Revision 0.01 - File Created
// Additional Comments:
// 
//////////////////////////////////////////////////////////////////////////////////
typedef enum logic [10:0] {
// R-type: {funct7, funct3, opcode} = 7+3+1... 
// Format: {ir30, funct3[2:0], opcode[6:0]} = 11 bits
// ir30 is bit 30 of the instruction (distinguishes ADD/SUB, SRL/SRA)
    ADD  = 11'b0_000_0110011,
    SUB  = 11'b1_000_0110011,
    BITWISE_AND  = 11'b0_111_0110011,
    BITWISE_OR   = 11'b0_110_0110011,
    BITWISE_XOR  = 11'b0_100_0110011,
    SLL  = 11'b0_001_0110011,
    SRL  = 11'b0_101_0110011,
    SRA  = 11'b1_101_0110011,
    SLT  = 11'b0_010_0110011,
    SLTU = 11'b0_011_0110011,
    // I-type arithmetic: opcode = 0010011
    ADDI  = 11'b0_000_0010011,
    ANDI  = 11'b0_111_0010011,
    ORI   = 11'b0_110_0010011,
    XORI  = 11'b0_100_0010011,
    SLLI  = 11'b0_001_0010011,
    SRLI  = 11'b0_101_0010011,
    SRAI  = 11'b1_101_0010011,
    SLTI  = 11'b0_010_0010011,
    SLTIU = 11'b0_011_0010011,   
    // Loads: opcode = 0000011
    LB  = 11'b0_000_0000011,
    LH  = 11'b0_001_0000011,
    LW  = 11'b0_010_0000011,
    LBU = 11'b0_100_0000011,
    LHU = 11'b0_101_0000011,    
    // Stores: opcode = 0100011
    SB = 11'b0_000_0100011,
    SH = 11'b0_001_0100011,
    SW = 11'b0_010_0100011,
    // Branches: opcode = 1100011
    BEQ  = 11'b0_000_1100011,
    BNE  = 11'b0_001_1100011,
    BLT  = 11'b0_100_1100011,
    BGE  = 11'b0_101_1100011,
    BLTU = 11'b0_110_1100011,
    BGEU = 11'b0_111_1100011,   
    // Jumps
    JAL1  = 11'b0_000_1101111,   // J-type, no funct3
    JALR1 = 11'b0_000_1100111,   // I-type, funct3=000    
    // Upper immediates
    LUI1   = 11'b0_000_0110111,  // U-type, no funct3
    AUIPC1 = 11'b0_000_0010111,  // U-type, no funct3   
    NOP =    11'b1_111_1111111,
    UNKNOWN =11'b0_111_1111111
} instruction_t;
 
typedef enum logic [6:0] {
    LUI      = 7'b0110111,
    AUIPC    = 7'b0010111,
    JAL      = 7'b1101111,
    JALR     = 7'b1100111,
    BRANCH   = 7'b1100011,
    LOAD     = 7'b0000011,
    STORE    = 7'b0100011,
    OP_IMMED   = 7'b0010011,
    OP       = 7'b0110011,
    SYSTEM   = 7'b1110011
 } opcode_t;
 
 
//===IF/ID Struct==
typedef struct packed{
    opcode_t opcode;
    logic [31:0] IR;
    logic [31:0] PC;
    logic [31:0] PC_PLUS_FOUR;
    instruction_t instruction;
} IF_ID_t;
//=================

//===ID/EX Struct==
typedef struct packed{
    logic [31:0] rs1;
    logic [31:0] rs2; //used for branch condtion and ALU
    logic [4:0]  rdAdr;
    logic [31:0] PC;
    logic [31:0] PC_PLUS_FOUR;
    logic [31:0] U_Type;
    logic [31:0] I_Type;
    logic [31:0] S_Type;
    logic [31:0] J_Type;
    logic [31:0] B_Type;
    logic [3:0] ALU_FUN;
    opcode_t opcode;
    logic srcA_SEL;
    logic [1:0] srcB_SEL;
    logic [2:0] PC_SEL;
    logic [1:0] RF_SEL;
    logic RF_WE;
    logic memWE1;
    logic memWE2;
    logic memRDEN1;
    logic memRDEN2;
    logic [1:0] mem_SIZE;
    logic mem_SIGN;
    logic [2:0] FUNC3;
    logic br_eq, br_lt, br_ltu;
    logic branch;
    instruction_t instruction;
} ID_EX_t;
//=================

//===EX/MEM Struct=
typedef struct packed{
    logic [2:0] PC_SEL;
    logic [31:0] PC_PLUS_FOUR;
    logic [1:0] RF_SEL;
    logic [31:0] rs2; //Used for memory data
    logic [31:0] ALU_RESULT; //Used for Reg data and Mem address
    logic [31:0] jalr; // in the future we can comapct all of these to a branch/jump value
    logic [31:0] branch;
    logic [31:0] jal;
    logic RF_WE;
    logic memWE2;
    logic memRDEN1; //hardcoded 1 outside this
    logic memRDEN2;
    logic [1:0] mem_SIZE;
    logic mem_SIGN;
    logic [4:0] rdAdr;
    instruction_t instruction;
} EX_MEM_t;
//=================

//==MEM/WB Struct==
typedef struct packed{
    logic RF_WE;
    logic [1:0] RF_SEL;
    logic [31:0] PC_PLUS_FOUR;
    logic [4:0] rdAdr;
    logic [31:0] W_DATA;
    instruction_t instruction;
} MEM_WB_t;
//=================

//===Begin Top Level====
module Drews_pipeline_toplevel(
    input CLK,
    input RESET,
    input [31:0] IOBUS_IN,
    output [31:0] IOBUS_OUT,
    output [31:0] IOBUS_ADDR,
    output logic IOBUS_WR
);  
//===Instantiate Reg and Wries====================
    //==IF Wires
    logic [31:0] pc;
    logic [31:0] ir; //DOUT1
    logic [31:0] DOUT2;
    logic [31:0] PC_PLUS_FOUR;
    instruction_t instruction;
    opcode_t OPCODE;
    //==ID Wires
    logic [31:0] rs1;
    logic [31:0] rs2;
    logic [4:0] rdAdr;
    logic [31:0] Utype;
    logic [31:0] Itype;
    logic [31:0] Stype;
    logic [31:0] Jtype;
    logic [31:0] SRC_A;
    logic [31:0] SRC_B;
    logic [31:0] ALU_RESULT;
    logic BR_EQ;
    logic BR_LT;
    logic BR_LTU;
    logic [31:0] Btype;
    logic srcA_SEL;
    logic [1:0] srcB_SEL;
    logic [2:0] PC_SEL;
    logic [1:0] RF_SEL;
    logic PC_WE, RF_WE, memWE2, memRDEN1, memRDEN2;
    logic [3:0] ALU_FUN;//Make the ALU ENUM
    //==EX Wires
    logic [2:0] PC_SEL_BRANCH;
    logic [31:0] jalr, branch, jal;
    //==MEM Wires
    logic [31:0] W_DATA;
//===============================================
   
    IF_ID_t IF_ID_REG;
    ID_EX_t ID_EX_REG, ID_EX_NEXT;
    EX_MEM_t EX_MEM_REG, EX_MEM_NEXT;
    MEM_WB_t MEM_WB_REG, MEM_WB_NEXT;
   
//=======Instruction Fetch STAGE====================================================================================================================
    logic [31:0] if_de_pc;
    always_ff @(posedge CLK) begin
        if (RESET) begin
            if_de_pc <= 32'b0;
        end
        else begin
            if_de_pc <= pc;
        end
    end  

    PC OTTER_PC(
        .CLK(CLK),
        .RST(RESET), //MCU level reset
        .PC_WRITE(1'b1),//Currently hardcoded 1, slater shoudl come from ex or mem
        .PC_SOURCE(EX_MEM_REG.PC_SEL),// comes from the MEM stage
        .JALR(EX_MEM_REG.jalr),
        .JAL(EX_MEM_REG.jal),
        .BRANCH(EX_MEM_REG.branch), //We can probablt get make all 3 inot on address and onyl control with SEL
        .MTVEC(32'b0), //irrelavent atm
        .MEPC(32'b0), //irrelavent atm
        .PC_OUT(pc),
        .PC_OUT_INC(PC_PLUS_FOUR));//This is a future PC plus 4
   
    Memory OTTER_MEMORY(
        .MEM_CLK(CLK),
        .MEM_RDEN1(1'b1), //this is hardcoded maybe later make form reg
        .MEM_RDEN2(EX_MEM_REG.memRDEN2),
        .MEM_WE2(EX_MEM_REG.memWE2),
        // changes
        .MEM_ADDR1(if_de_pc[15:2]),
        .MEM_ADDR2(EX_MEM_REG.ALU_RESULT),
        .MEM_DIN2(EX_MEM_REG.rs2),
        .MEM_SIZE(EX_MEM_REG.mem_SIZE),
        .MEM_SIGN(EX_MEM_REG.mem_SIGN),
        .IO_IN(IOBUS_IN),
        .IO_WR(IOBUS_WR),
        .MEM_DOUT1(ir),
        .MEM_DOUT2(DOUT2)
        );
        
always_comb begin
    if (ir == 32'h00000013)
        instruction = NOP;
    else if (ir[6:0] == 7'b0110111)
        instruction = LUI1;
    else if (ir[6:0] == 7'b0010111)
        instruction = AUIPC1;
    else if (ir[6:0] == 7'b1101111)
        instruction = JAL1;
    else begin
        case ({ir[30], ir[14:12], ir[6:0]})
            // R-type
            11'b0_000_0110011: instruction = ADD;
            11'b1_000_0110011: instruction = SUB;
            11'b0_111_0110011: instruction = BITWISE_AND;
            11'b0_110_0110011: instruction = BITWISE_OR;
            11'b0_100_0110011: instruction = BITWISE_XOR;
            11'b0_001_0110011: instruction = SLL;
            11'b0_101_0110011: instruction = SRL;
            11'b1_101_0110011: instruction = SRA;
            11'b0_010_0110011: instruction = SLT;
            11'b0_011_0110011: instruction = SLTU;
            // I-type arithmetic
            11'b0_000_0010011: instruction = ADDI;
            11'b0_111_0010011: instruction = ANDI;
            11'b0_110_0010011: instruction = ORI;
            11'b0_100_0010011: instruction = XORI;
            11'b0_001_0010011: instruction = SLLI;
            11'b0_101_0010011: instruction = SRLI;
            11'b1_101_0010011: instruction = SRAI;
            11'b0_010_0010011: instruction = SLTI;
            11'b0_011_0010011: instruction = SLTIU;
            // Loads
            11'b0_000_0000011: instruction = LB;
            11'b0_001_0000011: instruction = LH;
            11'b0_010_0000011: instruction = LW;
            11'b0_100_0000011: instruction = LBU;
            11'b0_101_0000011: instruction = LHU;
            // Stores
            11'b0_000_0100011: instruction = SB;
            11'b0_001_0100011: instruction = SH;
            11'b0_010_0100011: instruction = SW;
            // Branches
            11'b0_000_1100011: instruction = BEQ;
            11'b0_001_1100011: instruction = BNE;
            11'b0_100_1100011: instruction = BLT;
            11'b0_101_1100011: instruction = BGE;
            11'b0_110_1100011: instruction = BLTU;
            11'b0_111_1100011: instruction = BGEU;
            // Jumps & System
            11'b0_000_1100111: instruction = JALR1;
            default:           instruction = UNKNOWN;
        endcase
    end
end
//========Instruction Decode STAGE=======
    always_ff @(posedge CLK) begin
        if(RESET)
            IF_ID_REG <='0;
        else begin
            IF_ID_REG.PC <= pc;
            IF_ID_REG.IR <= ir;
            IF_ID_REG.PC_PLUS_FOUR <= PC_PLUS_FOUR; // we changed it because it's not right, right now
            IF_ID_REG.opcode <= opcode_t'(ir[6:0]);
            IF_ID_REG.instruction <= instruction;
            end
    end
   
   
    REG_FILE OTTER_REG_FILE(
    .CLK(CLK),
    .EN(MEM_WB_REG.RF_WE),
    .ADR1(IF_ID_REG.IR[19:15]),
    .ADR2(IF_ID_REG.IR[24:20]),
    .WA(MEM_WB_REG.rdAdr),
    .WD(MEM_WB_REG.W_DATA),
    .RS1(rs1),
    .RS2(rs2)
    );
   
    assign IOBUS_OUT = rs2; //they are they same, however i think IOBUS out needs to be syncronou
   
    ImmediateGenerator OTTER_IMGEN(
        .IR(IF_ID_REG.IR[31:7]),
        .U_TYPE(Utype),
        .I_TYPE(Itype),
        .S_TYPE(Stype),
        .B_TYPE(Btype),
        .J_TYPE(Jtype)
    );
   
   
   
    CU_DCDR OTTER_CU_DCDR(
        .IR_30(IF_ID_REG.IR[30]),
        .IR_FUNCT(IF_ID_REG.IR[14:12]),
        .IR_OPCODE(IF_ID_REG.opcode),
        .ALU_FUN(ALU_FUN),
        .ALU_SRCA(srcA_SEL),
        .ALU_SRCB(srcB_SEL),
        .PC_SOURCE(PC_SEL),
        .RF_WR_SEL(RF_SEL),
        .PC_WE(PC_WE),
        .RF_WE(RF_WE),
        .memWE2(memWE2),
        .memRDEN1(memRDEN1),//ATM we hardcode this to 0 when it matters
        .memRDEN2(memRDEN2)
    );
   
 
//===Execute STAGE PREP===
    always_comb begin
        ID_EX_NEXT.rs1 = rs1;
        ID_EX_NEXT.rs2 = rs2;
        ID_EX_NEXT.rdAdr = IF_ID_REG.IR[11:7];
        ID_EX_NEXT.PC = IF_ID_REG.PC;
        ID_EX_NEXT.U_Type = Utype;
        ID_EX_NEXT.I_Type = Itype;
        ID_EX_NEXT.S_Type = Stype;
        ID_EX_NEXT.J_Type = Jtype;
        ID_EX_NEXT.B_Type = Btype;
        ID_EX_NEXT.ALU_FUN = ALU_FUN;
        ID_EX_NEXT.srcA_SEL = srcA_SEL;
        ID_EX_NEXT.srcB_SEL = srcB_SEL;
        ID_EX_NEXT.PC_SEL = PC_SEL;
        ID_EX_NEXT.RF_SEL = RF_SEL;
        ID_EX_NEXT.memWE2 = memWE2;
        ID_EX_NEXT.memRDEN1 = memRDEN1;
        ID_EX_NEXT.memRDEN2 = memRDEN2;
        ID_EX_NEXT.mem_SIZE = IF_ID_REG.IR[13:12];
        ID_EX_NEXT.mem_SIGN = IF_ID_REG.IR[14];
        ID_EX_NEXT.FUNC3 = IF_ID_REG.IR[14:12];
        ID_EX_NEXT.opcode = IF_ID_REG.opcode;
        ID_EX_NEXT.PC_PLUS_FOUR = IF_ID_REG.PC_PLUS_FOUR;
        ID_EX_NEXT.instruction = IF_ID_REG.instruction;
        // NOP guard: kill control signals so NOPs can't write/store
        if (IF_ID_REG.instruction == NOP) begin
            ID_EX_NEXT.RF_WE   = 1'b0;
            ID_EX_NEXT.memWE2  = 1'b0;
            ID_EX_NEXT.memRDEN2 = 1'b0;
        end else begin
            ID_EX_NEXT.RF_WE = RF_WE;
        end
    end
   
//====Execute STAGE=============
    always_ff @(posedge CLK) begin
        if(RESET)
            ID_EX_REG <='0;
        else
            ID_EX_REG <= ID_EX_NEXT;
    end
    BCG OTTER_BRANCH_COND_GEN(
        .RS1(ID_EX_REG.rs1),
        .RS2(ID_EX_REG.rs2),
        .BR_EQ(BR_EQ),
        .BR_LT(BR_LT),
        .BR_LTU(BR_LTU)
    );
    TwoMux ALU_MUX_A(
        .ALU_SRC_A(ID_EX_REG.srcA_SEL),
        .RS1(ID_EX_REG.rs1),
        .U_TYPE(ID_EX_REG.U_Type),
        .SRC_A(SRC_A)
    );
   
    FourMux ALU_MUX_B(
        .SEL(ID_EX_REG.srcB_SEL),
        .ZERO(ID_EX_REG.rs2),
        .ONE(ID_EX_REG.I_Type),
        .TWO(ID_EX_REG.S_Type),
        .THREE(ID_EX_REG.PC),
        .OUT(SRC_B)
    );
   
    ALU OTTER_ALU(
    .SRC_A(SRC_A),
    .SRC_B(SRC_B),
    .ALU_FUN(ID_EX_REG.ALU_FUN),
    .RESULT(ALU_RESULT)
    );
    assign IOBUS_ADDR = ALU_RESULT;
    
    BAG OTTER_BRACNH_ADR_GEN(
        .RS1(ID_EX_REG.rs1),
        .I_TYPE(ID_EX_REG.I_Type),
        .J_TYPE(ID_EX_REG.J_Type),
        .B_TYPE(ID_EX_REG.B_Type),
        .FROM_PC(ID_EX_REG.PC),
        .JAL(jal),
        .JALR(jalr),
        .BRANCH(branch)
        );
   
    always_comb begin
    // Default: do not branch
    PC_SEL_BRANCH = ID_EX_REG.PC_SEL;
    if (ID_EX_REG.opcode == 7'b1100011) begin
        PC_SEL_BRANCH = 3'b000;   // or whatever means PC + 4 / no branch

        case (ID_EX_REG.FUNC3)
            3'b000: begin // BEQ
                if (BR_EQ)
                    PC_SEL_BRANCH = 3'b010;
            end

            3'b001: begin // BNE
                if (~BR_EQ)
                    PC_SEL_BRANCH = 3'b010;
            end

            3'b100: begin // BLT
                if (BR_LT)
                    PC_SEL_BRANCH = 3'b010;
            end

            3'b101: begin // BGE
                if (~BR_LT)
                    PC_SEL_BRANCH = 3'b010;
            end

            3'b110: begin // BLTU
                if (BR_LTU)
                    PC_SEL_BRANCH = 3'b010;
            end

            3'b111: begin // BGEU
                if (~BR_LTU)
                    PC_SEL_BRANCH = 3'b010;
            end

            default: begin
                PC_SEL_BRANCH = 3'b000;
            end
            endcase
        end
    end
   
    //====Memory STAGE PREP==============
    always_comb begin
            EX_MEM_NEXT.PC_SEL = PC_SEL_BRANCH;//Updates PC if branch
            EX_MEM_NEXT.rs2 = ID_EX_REG.rs2; //Used for memory data
            EX_MEM_NEXT.ALU_RESULT = ALU_RESULT; //Used for Reg data and Mem address
            EX_MEM_NEXT.jalr = jalr; // in the future we can comapct all of these to a branch/jump value
            EX_MEM_NEXT.branch = branch;
            EX_MEM_NEXT.jal = jal;
            EX_MEM_NEXT.RF_WE = ID_EX_REG.RF_WE;
            EX_MEM_NEXT.memWE2 = ID_EX_REG.memWE2;
            EX_MEM_NEXT.memRDEN1 = ID_EX_REG.memRDEN1; //hardcoded 1 outside this
            EX_MEM_NEXT.memRDEN2 = ID_EX_REG.memRDEN2;
            EX_MEM_NEXT.mem_SIZE = ID_EX_REG.mem_SIZE;
            EX_MEM_NEXT.mem_SIGN = ID_EX_REG.mem_SIGN;
            EX_MEM_NEXT.rdAdr = ID_EX_REG.rdAdr;
            EX_MEM_NEXT.PC_PLUS_FOUR = ID_EX_REG.PC_PLUS_FOUR;
            EX_MEM_NEXT.RF_SEL = ID_EX_REG.RF_SEL;
            EX_MEM_NEXT.instruction = ID_EX_REG.instruction;
        end
    //===Memory STAGE============================
    always_ff @(posedge CLK) begin
        if(RESET)
            EX_MEM_REG <='0;
        else
            EX_MEM_REG <= EX_MEM_NEXT;
    end
         FourMux RF_MUX(
        .SEL(EX_MEM_REG.RF_SEL),
        .ZERO(EX_MEM_REG.PC_PLUS_FOUR),
        .ONE(32'hDEADBEEF),
        .TWO(DOUT2),
        .THREE(EX_MEM_REG.ALU_RESULT),
        .OUT(W_DATA)
    );
    //===Write Back STAGE PREP===========
    always_comb begin
        MEM_WB_NEXT.RF_WE = EX_MEM_REG.RF_WE;
        MEM_WB_NEXT.W_DATA = W_DATA;
        MEM_WB_NEXT.rdAdr = EX_MEM_REG.rdAdr;
        MEM_WB_NEXT.instruction = EX_MEM_REG.instruction;
        MEM_WB_NEXT.RF_SEL = EX_MEM_REG.RF_SEL;
    end
    //===Write Back STAGE=====================
    always_ff @(posedge CLK) begin
        if(RESET)
            MEM_WB_REG <= '0;
        else
            MEM_WB_REG <= MEM_WB_NEXT;
    end

endmodule
